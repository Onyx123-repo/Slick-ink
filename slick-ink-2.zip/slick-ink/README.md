# Slick Ink

Static site: plain HTML, CSS and JavaScript. No build step, no backend.

## Folder

```
slick-ink/
├── index.html
├── css/style.css
├── js/script.js
├── assets/        <- logo and photos
└── README.md
```

## Placeholder content: replace before launch

All of this is invented so the site looks complete. Search `index.html` and replace it with the client's real details:

- Artist name: `Marco Vale`
- City and address: `Portland`, `123 Main Street, Suite 4`
- Hours, deposit and walk-in policy, pricing wording (FAQ and "The shop")
- Bio (artist section), the three styles (Styles section and the form's Style list)
- Selected work: `assets/work-01.webp` to `work-06.webp` are demo pictures found online, not the artist's own work. Replace them with the artist's own tattoo photos before launch. Don't publish other artists' work without permission.
- Business name: the site says "Slick Ink", but the sign in the shop photos reads "Sick Ink Studios". Confirm the real name, then replace it everywhere.

## Before launch

1. **Signal link.** Set `SIGNAL_URL` at the top of `js/script.js`. Every "Message on Signal" and "Open Signal" link uses it.
2. **Logo.** Save it as `assets/logo.jpg`, then swap the text brand in `index.html` for the commented `<img>` line.
3. **Tattoo photos.** Export as WebP, about 800 x 1000 px, under 150 KB each. Replace each `<div class="tile ph">` with the commented `<button class="tile">` example and write real alt text. Clicking a photo enlarges it.
4. **Shop photos.** The four in `assets/` are about 650 to 750 px wide. Swap in larger originals if available.
5. **Fonts.** Anton (headings) and Archivo (body) load from Google Fonts. Check them against the real logo.

## Known limits (version one)

- The form stores and sends nothing. It builds a summary the customer copies and pastes into Signal.
- Signal links can't prefill a message, so the customer sends it themselves.
- Reference images are sent in Signal, not through the form.

## Deploy to Vercel

1. Put the folder in a GitHub repo.
2. In Vercel choose Add New, then Project, import the repo and deploy. Framework preset: Other. No build command, no output directory.
3. Open the live URL on a phone and a desktop. Test the menu, gallery, form errors, Copy inquiry and the Signal link.
