(() => {
  // Replace with the artist's real Signal contact link (the only place it is set).
  const SIGNAL_URL = 'https://signal.me/#eu/REPLACE-WITH-ARTIST-LINK';

  const $ = (s, r = document) => r.querySelector(s);

  document.querySelectorAll('a.signal').forEach(a => { a.href = SIGNAL_URL; });

  // Mobile menu
  const menu = $('.menu'), nav = $('#nav');
  const setMenu = open => {
    nav.classList.toggle('open', open);
    menu.setAttribute('aria-expanded', String(open));
  };
  menu.addEventListener('click', () => setMenu(!nav.classList.contains('open')));
  nav.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });

  // Gallery lightbox: opens for any .tile that contains a real <img>
  const box = $('#lightbox'), big = $('img', box);
  document.addEventListener('click', e => {
    const img = e.target.closest('.tile img');
    if (!img || !box.showModal) return;
    big.src = img.currentSrc || img.src;
    big.alt = img.alt;
    box.showModal();
  });
  box.addEventListener('click', e => {
    if (e.target === box || e.target.closest('.x')) box.close();
  });

  // Consultation form
  const form = $('#form'), result = $('#result'), summary = $('#summary'), msg = $('#copy-msg');
  const rules = {
    name: v => v.trim() ? '' : 'Enter your name.',
    idea: v => v.trim().length >= 15 ? '' : 'Describe your idea in at least 15 characters.',
    placement: v => v.trim() ? '' : 'Say where on your body you want the tattoo.'
  };
  const check = id => {
    const el = form.elements[id], text = rules[id](el.value);
    $('#e-' + id).textContent = text;
    el.setAttribute('aria-invalid', text ? 'true' : 'false');
    return text ? el : null;
  };

  form.addEventListener('input', e => {
    if (rules[e.target.id] && e.target.getAttribute('aria-invalid') === 'true') check(e.target.id);
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    const bad = Object.keys(rules).map(check).filter(Boolean);
    if (bad.length) { bad[0].focus(); return; }

    const v = id => form.elements[id].value.trim();
    const line = (label, val) => val ? `${label}: ${val}` : '';
    summary.value = [
      'Hi, I would like a tattoo consultation.',
      line('Name', v('name')),
      line('Contact', v('contact')),
      line('Idea', v('idea')),
      line('Style', v('style')),
      line('Placement', v('placement')),
      line('Size', v('size')),
      line('Budget', v('budget')),
      line('Availability', v('dates')),
      'I will send reference images here.'
    ].filter(Boolean).join('\n');

    msg.textContent = '';
    result.hidden = false;
    result.scrollIntoView({ behavior: 'smooth', block: 'start' });
    $('#result-h').focus({ preventScroll: true });
  });

  // Copy with fallback for browsers that block the clipboard API
  const done = 'Copied. Now open Signal and paste it.';
  $('#copy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(summary.value);
      msg.textContent = done;
    } catch {
      summary.focus();
      summary.select();
      summary.setSelectionRange(0, summary.value.length);
      let ok = false;
      try { ok = document.execCommand('copy'); } catch {}
      msg.textContent = ok ? done : 'Copying didn’t work. The text is selected: press and hold it, choose Copy, then paste it in Signal.';
    }
  });
})();
